package com.cochlear.ai;

import android.util.Log;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Status;
import io.grpc.stub.StreamObserver;

import com.cochlear.ai.cochlear_senseGrpc.cochlear_senseStub;
import com.google.protobuf.ByteString;
import com.cochlear.ai.cochlear_senseGrpc;


import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import com.cochlear.ai.CochlearSense.input;
import com.cochlear.ai.CochlearSense.output;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;



public class CochlearSenseStreamClient {
    private static final long deadline = 10;

    ManagedChannel channel;
    cochlear_senseStub asyncStub;
    CountDownLatch finishLatch;
    StreamObserver<input> requestObserver;

    //Queue<String> responses = new ConcurrentLinkedQueue<String>();

    private String apiKey;
    private float fs;
    private int bitrate;
    private boolean isRunning = false;

    public static enum ServiceType {
        //Stream service
        eventStream, // 22050 - 0.5sec
        ageGenderStream, // 16000 - 0.5sec
        musicGenreStream, // 22050
        musicMoodStream, //22050 - Not yet implemented
        musicDetectorStream, //22050
        speechDetectorStream, //22050
    }

    private static final Map<ServiceType, Integer> SAMPLE_RATE = Collections.unmodifiableMap(
            new HashMap<ServiceType, Integer>() {{
                put(ServiceType.eventStream, 22050  );
                put(ServiceType.ageGenderStream,  16000);
                put(ServiceType.musicGenreStream,  22050);
                put(ServiceType.musicMoodStream,  22050);
                put(ServiceType.musicDetectorStream,  16000);
                put(ServiceType.speechDetectorStream,  16000);
            }});

    public CochlearSenseStreamClient(String host, int port, String apiKey) {
        this(ManagedChannelBuilder.forAddress(host, port).usePlaintext());
        this.apiKey = apiKey;
    }

    /** Construct client for accessing RouteGuide server using the existing channel. */
    private CochlearSenseStreamClient(ManagedChannelBuilder<?> channelBuilder) {
        super();
        channel = channelBuilder.build();
        asyncStub = cochlear_senseGrpc.newStub(channel);
    }




    public CochlearSenseStreamClient senseSpeechDetectorStream() throws Exception{
        senseStream(ServiceType.speechDetectorStream);
        return this;
    }
    public CochlearSenseStreamClient senseMusicDetectorStream() throws Exception{
        senseStream(ServiceType.musicDetectorStream);
        return this;
    }

    public void end() {
        isRunning = false;
        requestObserver.onCompleted();
    }

    public void push(byte[] bytes) {
        input _input = input.newBuilder()
                .setData(ByteString.copyFrom(bytes))
                .setSubtask("")
                .setApikey(apiKey)
                .setDtype("float32")
                .setSr(16000)
                .build();
        requestObserver.onNext(_input);



    }




    private void senseStream(ServiceType type) throws Exception{

        finishLatch= new CountDownLatch(1);

        class BistreamObserver implements StreamObserver<output>{
            @Override
            public void onNext(output out) {
                //CochlearSenseStreamClient.this.yield(out.getPred());
                Log.d("CochlearSenseResult", out.getPred());
                //responses.add(out.getPred());
            }

            @Override
            public void onError(Throwable t) {
                Status status = Status.fromThrowable(t);
                System.err.println("ERROR " + status);
                finishLatch.countDown();
            }

            @Override
            public void onCompleted() {
                System.out.println("Finished from server");
                finishLatch.countDown();

            }
        }

        switch(type) {
            case eventStream:
                requestObserver = asyncStub
                        .withDeadlineAfter(deadline, TimeUnit.MINUTES)
                        .eventStream(new BistreamObserver());
                break;
            case ageGenderStream:
                requestObserver = asyncStub
                        .withDeadlineAfter(deadline, TimeUnit.MINUTES)
                        .ageGenderStream(new BistreamObserver());
                break;
            case musicGenreStream:
                requestObserver = asyncStub
                        .withDeadlineAfter(deadline, TimeUnit.MINUTES)
                        .musicGenreStream(new BistreamObserver());
                break;
            case musicMoodStream:
                requestObserver = asyncStub
                        .withDeadlineAfter(deadline, TimeUnit.MINUTES)
                        .musicMoodStream(new BistreamObserver());
                break;
            case musicDetectorStream:
                requestObserver = asyncStub
                        .withDeadlineAfter(deadline, TimeUnit.MINUTES)
                        .musicDetectorStream(new BistreamObserver());
                break;
            case speechDetectorStream:
                requestObserver = asyncStub
                        .withDeadlineAfter(deadline, TimeUnit.MINUTES)
                        .speechDetectorStream(new BistreamObserver());
                break;
            default:
                throw new Exception("CochlearSenseStreamClient - Unknown stream service name was given");
        }


    }

}
